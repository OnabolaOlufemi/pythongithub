# Assignment Q1: Create a program that adds two fractions.
# Code has been modified to handle other operators, as well as additions. Results will however be in undesired decimal format.
# A single program might not be able to compute all (/,*,-,+) and still give results in fraction format. 

print('Additions, subtractions, multiplications and divisions can all be performed. Spaces should not be ignored.')
calculation = input('Please enter the fraction calculation in the format a / b + c / d: ')
broken_calculation = calculation.split()
print(broken_calculation)
a = int(broken_calculation[0]) ## the top of fraction 1
b = int(broken_calculation[2]) ## the bottom of fraction 1
c = int(broken_calculation[4]) ## the top of fraction 2
d = int(broken_calculation[6]) ## the bottom of fraction 2
fraction1 = a/b
fraction2 = c/d
sign = broken_calculation[3]

# Next if/else statements to perform whatever calculations were inputted are added
if sign == '+':
    print('You have decided to add your fractions.\nA solution for this provided below')
    print(fraction1+fraction2)
elif sign == '-':
    print('You have decided to subtract your fractions.\nA solution for this provided below')
    print(fraction1-fraction2)
elif sign == '*':
    print('You have decided to multiply your fractions.\nA solution for this provided below')
    print(fraction1*fraction2)
elif sign == '/':
    print('You have decided to divide your fractions.\nA solution for this provided below')
    print(fraction1/fraction2)
else:
    print('Error! There is something wrong with your input, check it again.\nMake sure there are spaces between your fractions and the operator.')