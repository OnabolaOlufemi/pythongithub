# Assignment Q1: Create a program that adds two fractions.
# Unlike Assignment2_Code1, this program handles the question and computes only additions.

print('Only fraction additions can be performed by this program. Input spaces should not be ignored')
# The user is asked to input their calculation
calculation = input('Please enter the fraction calculation in the format "a/b + c/d" here: ')
# The + (addition operator) is replaced with a '/' to facilitate the string-to-list split
changed_calculation = calculation.replace('+', '/')
# The new string is then split to create the list.
broken_calculation = changed_calculation.split('/')
# print(broken_calculation) # you can add this line to check how your list has been created

a = int(broken_calculation[0]) # the top of fraction 1
b = int(broken_calculation[1]) # the bottom of fraction 1
c = int(broken_calculation[2]) # the top of fraction 2
d = int(broken_calculation[3]) # the bottom of fraction 2

# these two variables are obtained from the hand calculation of adding two hypothetical fractions "a/b" and "c/d"
fraction_top = (a*d)+(b*c)
fraction_bottom = b*d

fraction_sum = f'The solution to your input is {fraction_top}/{fraction_bottom}'
print(fraction_sum)