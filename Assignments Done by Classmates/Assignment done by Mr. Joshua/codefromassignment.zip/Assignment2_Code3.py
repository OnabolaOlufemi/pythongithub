# Assignment Q2: Create a program that tells if a number is odd or even.

# The basis for the calculation will be whether the number is divisible (w/out a remainder) by 2 or not.
input_number = int(input('Please enter an integer: '))

# Now, if/else statements are used to check whether its odd/even.
if input_number%2 == 0:
    print(f'The number you have inputted ({input_number}) is an even number')
else:
    print(f'The number you have inputted ({input_number}) is an odd number')