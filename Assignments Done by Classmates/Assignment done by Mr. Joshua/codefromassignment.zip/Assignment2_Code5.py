# Assignment Q3: Write a program to print the 12 multiples of a number given by the user in the format below.

number = int(input('Please enter an integer you will like to see a table for: '))

# The first character in the range function denotes the start, second denotes an unincluded end.
# A third character could be added to denote a step for the range.
for i in range(0,13):
    print(f'{number} * {i} = {number*i}')