# Assignment Q3: Write a program to print the reversed form of a string input by a user.

# This string reversing will be done by way of the 'slicing' approach.
# In indexed brackets [::-1], the first colon signifies the end of the string and second signifies the beginning.
# The third indicates the direction, -1 indicates back to front (or last to first.)

input_string = input('Please input the characters you will like to reverse here: ')
reversed_string = input_string[::-1]

output = f'\nThe reverse of your input is {reversed_string}'
print(output)

# For a palindrome, the input_string and reversed_string variables will match. Therefore:
if input_string == reversed_string:
    print('\nNote: Your input is a palindrome')
else:
    print('\nNote: Your input is not a palindrome')